#!/usr/bin/python3
# -*- coding: utf-8 -*-
import os
import sys
import shutil

srcFile = 'files/simcrypt-v1.0beta-unix.py'

def checkPermissions():
    currUID = os.getuid()

    if currUID > 0:
        print("Setup executed by normal user!")
        print("Can install without admin rights.")
        _adminRights = False
    else:
        print("Will run full installation to /usr/bin...")
        _adminRights = True

    return _adminRights


# ===== main ===== #
def __main(is_root, src_file):
    if is_root:
        destFile = "/usr/bin/simcrypt.py"
    else:
        homeDir = os.getenv("HOME")
        os.mkdir(homeDir+"/.simcrypt")
        destFile = "{0}/.simcrypt/simcrypt.py".format(homeDir)

    try:
        shutil.copy(src_file, destFile)

        print("Installation success!")
    except Exception as err:
        print("ERR: {0}".format(str(err)))
        print("Installation failed!")
        
    

    
if __name__ == '__main__':
    print("Starting setup...")
    isAdmin = checkPermissions()

    confirm = input("Wanna install now? [y/N]: ")
    if confirm in "y Y yes Yes 1":
        __main(isAdmin, srcFile)
    else:
        print("Aborting.....")
        exit(0)
    
